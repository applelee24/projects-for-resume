/*********************************************************
*    TITLE:  GraphMatrix.h                               *
*    AUTHOR: Alexandra Lee                               *
*    DATE:   April 29, 2020                              *
**********************************************************/

#ifndef GRAPH_MATRIX_H
#define GRAPH_MATRIX_H
#include <iostream>

using namespace std;

class GraphMatrix {
// private attributes
private:
	int **vertexMatrix;
	int numVertices;
	int numEdges;

// public member functions
public:
    // constructor
	GraphMatrix(int numVertices) {
		this->numVertices = numVertices;
		vertexMatrix = new int*[numVertices];
		for (int i = 0; i < numVertices; i++){
			vertexMatrix[i] = new int[numVertices];
			for (int j = 0; j < numVertices; j++){
				vertexMatrix[i][j] = 0;
			}
		}
	}

    // destructor
	~GraphMatrix(){
		for (int i = 0; i < numVertices; i++) {
			delete[] vertexMatrix[i];
		}
		delete[] vertexMatrix;
	}

    // sets the 2D array to 1 at that element in the matrix
	void addEdge(int startVertex, int endVertex) {
		vertexMatrix[startVertex][endVertex] = 1;
	}

    // prints the matrix
	void printGraph() {
		cout << endl << "Adjacency Matrix:" << endl;
		for (int i = 0; i < numVertices; i++){
			for (int j = 0; j < numVertices; j++){
				cout << vertexMatrix[i][j] << " ";
			}
			cout << endl;
		}
	}

    /* accepts a row and column index and will return true if the matrix element is equal
       to 1 or false otherwise */
	bool isThereAnEdge(int source, int dest) {
		return vertexMatrix[source][dest] == 1;
	}

    // to determine which vertex to start with so that all nodes are included
	int getFirstVertex() {
		bool noSource;
		for (int col = 0; col < numVertices; col++) {
			noSource = true;
			for (int row = 0; row < numVertices; row++) {
				if (vertexMatrix[row][col] == 1){
					noSource = false;
					break;
				}
			}
			if (noSource) {
				return col;
			}
		}
		return 0;
	}
};

#endif
