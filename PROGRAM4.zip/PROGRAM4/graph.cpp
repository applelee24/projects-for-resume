/*********************************************************
*    TITLE:       graph.cpp                              *
*    AUTHOR:      Alexandra Lee                          *
*    DATE:        April 29, 2020                         *
*    DESCRIPTION: The user is asked for the name of a    *
*                 correct file (ex. graph_1.txt). Then   *
*                 the program should create and print    *
*                 an adjacency matrix. Next, it should   *
*                 create and print an adjacency list.    *
*                 Finally, it should print out the order *
*                 the vertices are traversed using DFS   *
*                 algorithm. If the graph has a cycle,   *
*                 the program will print out a message.  *
**********************************************************/

#include "Stack.h"
#include "GraphMatrix.h"
#include "GraphList.h"
#include <iostream>
#include <fstream>
#include <string>

using namespace std;

// recursive depth-first search
bool dfs(GraphMatrix &adjMat, Stack<int> &stack, bool visited[], int source, int numVertices) {

	bool hasCycle = false;

	stack.push(source);
	visited[source] = true;
	cout << source << "   ";
	
	for (int dest = 0; dest < numVertices; dest++){
		if (adjMat.isThereAnEdge(source, dest)){

			// acyclic if stack already has destination vertex
			if (stack.find(dest)){
				hasCycle = true;
			}
			else if(!visited[dest]){
				hasCycle = hasCycle || dfs(adjMat, stack, visited, dest, numVertices);
			}
		}
	}

	stack.pop(source);
	return hasCycle;
}

/* asks the user for a file that will create and print an adjacency matrix, adjacency list, the DFS order,
   and whether the graph has a cycle */
int main() {
	string fileName;
	int numVertices, startVertex, endVertex;

	cout << "Enter the name of your file that contains the graph vertices: ";
	cin >> fileName;
	ifstream infile(fileName);
	if (!infile){
		cout << "Error opening " << fileName;
		return 1;
	}

	infile >> numVertices;

	GraphMatrix adjMat(numVertices);
	GraphList adjList(numVertices);

	while (infile >> startVertex >> endVertex){
		adjMat.addEdge(startVertex, endVertex);
		adjList.addEdge(startVertex, endVertex);
	}

	infile.close();

	adjMat.printGraph();
	adjList.printGraph();

	Stack<int> stack;
	bool *visited = new bool[numVertices];
	for (int i = 0; i < numVertices; i++){
		visited[i] = false;
	}

	int firstVertex = adjMat.getFirstVertex();

	cout << endl << "Now traversing & printing graph vertices with DFS." << endl << endl;
	bool hasCycle = dfs(adjMat, stack, visited, firstVertex, numVertices);
    cout << endl;

    // displays if the graph has a cycle
	if (hasCycle){
		cout << endl << "Ah shooty pooty. This graph has a cycle." << endl;
	}

	delete[] visited;
	return 0;
}
