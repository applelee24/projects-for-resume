/*********************************************************
*    TITLE:  GraphList.h                                 *
*    AUTHOR: Alexandra Lee                               *
*    DATE:   April 29, 2020                              *
**********************************************************/

#ifndef GRAPH_LIST_H
#define GRAPH_LIST_H
#include <iostream>

class GraphList {
// private attributes
private:
	struct ListNode {
		int value;
		ListNode *next;
	};

	ListNode **headArray;
	int numVertices;
	int numEdges;
    
// public member functions
public:
    // constructor
	GraphList(int numVertices) {
		this->numVertices = numVertices;
		headArray = new ListNode*[numVertices];
		for (int i = 0; i < numVertices; i++){
			headArray[i] = new ListNode();
			headArray[i]->value = i;
			headArray[i]->next = NULL;
		}
	}

    // destructor
	~GraphList() {
		for (int i = 0; i < numVertices; i++) {
			ListNode *curr = headArray[i], *next;
			while (curr != NULL) {
				next = curr->next;
				delete curr;
				curr = next;
			}
		}
		delete[] headArray;
	}

    // create the node and add it to appropriate linked list
	void addEdge(int startVertex, int endVertex) {
		ListNode *newNode = new ListNode();
		newNode->value = endVertex;
		newNode->next = NULL;

		ListNode *curr = headArray[startVertex];
		while (curr->next != NULL) {
			curr = curr->next;
		}
		curr->next = newNode;
	}

    // prints the list
	void printGraph() {
		cout << endl << "Adjacency List..." << endl;
		for (int i = 0; i < numVertices; i++) {
			ListNode *curr = headArray[i];
			while (curr != NULL){
				cout << curr->value << "--->";
				curr = curr->next;
			}
			cout << "NULL" << endl;
		}
	}
};

#endif
