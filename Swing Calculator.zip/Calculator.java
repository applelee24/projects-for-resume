import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

public class Calculator extends JFrame implements ActionListener {

	// Attributes..
	private JPanel mainPanel;
	private JTextField resultField, operandField;
	private JButton reset, clear, seven, eight, nine, plus,
		four, five, six, subtract, one, two,
		three, multiply, zero, dot, divide;
	private char operation = ' ';
	
	public Calculator() {
		
		// Frame
		setTitle("Java Swing GUI Calculator");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setResizable(false);
		setSize(330, 400);
		
		// Main Panel.
		mainPanel = new JPanel();
		mainPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		mainPanel.setLayout(new GridLayout(7, 2, 6, 6));
		setContentPane(mainPanel);
		
		// Adding components..
		addingComponents();
		
		setVisible(true);
		
	}
	
	// Adding calculator.
	private void addingComponents() {
		
		JLabel resultLabel = new JLabel("Result Field");
		resultLabel.setHorizontalAlignment(SwingConstants.CENTER);
		mainPanel.add(resultLabel);
		
		JLabel operandLabel = new JLabel("Operand Field");
		operandLabel.setHorizontalAlignment(SwingConstants.CENTER);
		mainPanel.add(operandLabel);
		
		resultField = new JTextField();
		resultField.setEditable(false);
		resultField.setText("0.0");
		mainPanel.add(resultField);
		resultField.setColumns(10);
		
		operandField = new JTextField("0");
		operandField.setEditable(false);
		mainPanel.add(operandField);
		operandField.setColumns(10);
		
		reset = new JButton("Reset");
		reset.addActionListener(this);
		mainPanel.add(reset);
		
		clear = new JButton("Clear");
		clear.addActionListener(this);
		mainPanel.add(clear);
		
		JPanel firstPanel = new JPanel();
		mainPanel.add(firstPanel);
		firstPanel.setLayout(new BorderLayout(0, 0));
		
		eight = new JButton("8");
		eight.addActionListener(this);
		firstPanel.add(eight, BorderLayout.EAST);
		
		seven = new JButton("7");
		seven.addActionListener(this);
		firstPanel.add(seven, BorderLayout.WEST);
		
		JPanel secondPanel = new JPanel();
		mainPanel.add(secondPanel);
		secondPanel.setLayout(new BorderLayout(0, 0));
		
		plus = new JButton("+");
		plus.addActionListener(this);
		secondPanel.add(plus, BorderLayout.EAST);
		
		nine = new JButton("9");
		nine.addActionListener(this);
		secondPanel.add(nine, BorderLayout.WEST);
		
		JPanel thirdPanel = new JPanel();
		mainPanel.add(thirdPanel);
		thirdPanel.setLayout(new BorderLayout(0, 0));
		
		five = new JButton("5");
		five.addActionListener(this);
		thirdPanel.add(five, BorderLayout.EAST);
		
		four = new JButton("4");
		four.addActionListener(this);
		thirdPanel.add(four, BorderLayout.WEST);
		
		JPanel fourthPanel = new JPanel();
		mainPanel.add(fourthPanel);
		fourthPanel.setLayout(new BorderLayout(0, 0));
		
		subtract = new JButton("-");
		subtract.addActionListener(this);
		fourthPanel.add(subtract, BorderLayout.EAST);
		
		six = new JButton("6");
		six.addActionListener(this);
		fourthPanel.add(six, BorderLayout.WEST);
		
		JPanel fifthPanel = new JPanel();
		mainPanel.add(fifthPanel);
		fifthPanel.setLayout(new BorderLayout(0, 0));
		
		two = new JButton("2");
		two.addActionListener(this);
		fifthPanel.add(two, BorderLayout.EAST);
		
		one = new JButton("1");
		one.addActionListener(this);
		fifthPanel.add(one, BorderLayout.WEST);
		
		JPanel sixthPanel = new JPanel();
		mainPanel.add(sixthPanel);
		sixthPanel.setLayout(new BorderLayout(0, 0));
		
		multiply = new JButton("*");
		multiply.addActionListener(this);
		sixthPanel.add(multiply, BorderLayout.EAST);
		
		three = new JButton("3");
		three.addActionListener(this);
		sixthPanel.add(three, BorderLayout.WEST);
		
		zero = new JButton("0");
		zero.addActionListener(this);
		mainPanel.add(zero);
		
		JPanel seventhPanel = new JPanel();
		mainPanel.add(seventhPanel);
		seventhPanel.setLayout(new BorderLayout(0, 0));
		
		divide = new JButton("/");
		divide.addActionListener(this);
		seventhPanel.add(divide, BorderLayout.EAST);
		
		dot = new JButton(".");
		dot.addActionListener(this);
		seventhPanel.add(dot, BorderLayout.WEST);
		
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource() == reset) {

			resultField.setText("0.0");
			operation = ' ';
			operandField.setText("0");
			
		} else if(e.getSource() == clear) {
			
			operandField.setText("0");
			
		} else if(e.getSource() == dot) {
			
			String value = operandField.getText();
			if(!value.contains(".")) {
				operandField.setText(operandField.getText()+".");
			}
			
		} else if(e.getSource() == divide || e.getSource() == multiply || 
				e.getSource() == plus || e.getSource() == subtract) {
			
			double operandNumber = Double.parseDouble(operandField.getText());
			char currentOperation;
			if(e.getSource() == divide) {
				currentOperation = '/';
			} else if(e.getSource() == multiply) {
				currentOperation = '*';
			} else if(e.getSource() == plus) {
				currentOperation = '+';
			} else {
				currentOperation = '-';
			}
			if(operation == ' ') {
				
				resultField.setText(String.valueOf(operandNumber));
				operation = currentOperation;
				
			} else {
				
				double secondNumber = Double.parseDouble(resultField.getText());
				try {
					
					double result = doOperation(secondNumber, operandNumber);
					resultField.setText(String.valueOf(result));
					operation = currentOperation;
				
				} catch (DivisonByZeroException e1) {
					JOptionPane.showMessageDialog(null, e1.toString());
				}
				
			}
			operandField.setText("0");
			
		} else {
			
			String value = operandField.getText();
			if(value.equals("0")) {
				operandField.setText(e.getActionCommand());
			} else {
				operandField.setText(operandField.getText() + e.getActionCommand());
			}
			
		}
		
	}
	
	private double doOperation(double secondNumber, double operandNumber) throws DivisonByZeroException {
		
		double result = 0;
		if(operation == '/') {
			if(operandNumber == 0) {
				throw new DivisonByZeroException("Divison by zero is not allowed.");
			}
			result = secondNumber / operandNumber;
		} else if(operation == '*') {
			result = secondNumber * operandNumber;
		} else if(operation == '+') {
			result = secondNumber + operandNumber;
		} else if(operation == '-') {
			result = secondNumber - operandNumber;
		}
		return result;
		
	}
	
	// Main method of calculator.
	public static void main(String[] args) {
		
		new Calculator();
		
	}

}
