
public class DivisonByZeroException extends Exception {
	
	private String msg;
	
	public DivisonByZeroException(String msg) {
		
		this.msg = msg;
		
	}
	
	@Override
	public String toString() {
		
		return "DivisonByZeroException => " + msg;
		
	}

}
